CREATE PROCEDURE sp_ConsultarFarmacia
    @filtro VARCHAR(100)
AS
BEGIN
    SELECT * FROM farmacias
    WHERE nombre LIKE '%' + @filtro + '%'
       OR barrio LIKE '%' + @filtro + '%';
END;
go

