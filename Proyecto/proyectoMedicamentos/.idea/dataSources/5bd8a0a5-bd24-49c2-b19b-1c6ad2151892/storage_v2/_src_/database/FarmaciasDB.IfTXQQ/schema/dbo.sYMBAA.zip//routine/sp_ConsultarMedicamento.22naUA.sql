CREATE PROCEDURE sp_ConsultarMedicamento
    @nombre VARCHAR(100)
AS
BEGIN
    SELECT * FROM Medicamentos
    WHERE nombre_comercial LIKE '%' + @nombre + '%'
       OR nombre_generico LIKE '%' + @nombre + '%';
END;
go

