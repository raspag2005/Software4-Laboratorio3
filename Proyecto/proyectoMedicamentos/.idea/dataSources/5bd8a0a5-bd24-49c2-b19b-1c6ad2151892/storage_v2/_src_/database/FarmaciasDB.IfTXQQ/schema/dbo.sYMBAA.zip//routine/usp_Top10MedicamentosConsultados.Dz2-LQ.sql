CREATE PROCEDURE usp_Top10MedicamentosConsultados
AS
BEGIN
    SELECT TOP 10 M.id_medicamento, M.nombre_comercial, M.nombre_generico, COUNT(*) AS total_consultas
    FROM Consultas_Medicamentos C
    JOIN Medicamentos M ON C.id_medicamento = M.id_medicamento
    GROUP BY M.id_medicamento, M.nombre_comercial, M.nombre_generico
    ORDER BY total_consultas DESC;
END;
go

