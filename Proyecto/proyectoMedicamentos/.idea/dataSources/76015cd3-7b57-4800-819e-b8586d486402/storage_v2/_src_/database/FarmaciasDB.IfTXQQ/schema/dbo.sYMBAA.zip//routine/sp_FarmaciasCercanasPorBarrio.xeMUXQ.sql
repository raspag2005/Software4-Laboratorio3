CREATE PROCEDURE sp_FarmaciasCercanasPorBarrio
    @barrioUsuario VARCHAR(100)
AS
BEGIN
    SELECT 
        f.nombre AS NombreFarmacia,
        f.barrio,
        f.direccion,
        fm.precio,
        m.nombre_comercial AS Medicamento
    FROM 
        farmacias f
    INNER JOIN 
        Farmacia_Medicamento fm ON f.id_farmacia = fm.id_farmacia
    INNER JOIN 
        Medicamentos m ON fm.id_medicamento = m.id_medicamento
    WHERE 
        f.barrio = @barrioUsuario
    ORDER BY 
        fm.precio ASC;
END;
go

