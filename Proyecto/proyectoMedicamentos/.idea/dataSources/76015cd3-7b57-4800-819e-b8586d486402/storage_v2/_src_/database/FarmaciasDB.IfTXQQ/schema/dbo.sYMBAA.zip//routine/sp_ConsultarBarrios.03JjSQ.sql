CREATE PROCEDURE sp_ConsultarBarrios
AS
BEGIN
    SELECT DISTINCT barrio
    FROM Farmacias
    ORDER BY barrio;
END;
go

