CREATE PROCEDURE sp_Top10MedicamentosMasConsultados
AS
BEGIN
    SELECT TOP 10
        id_medicamento,
        nombre_comercial,
        total_consultas
    FROM Medicamentos
    ORDER BY total_consultas DESC;
END;
go

