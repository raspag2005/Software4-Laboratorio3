CREATE PROCEDURE sp_ConsultarTodosMedicamentos
AS
BEGIN
    SELECT * FROM Medicamentos
END;
go

