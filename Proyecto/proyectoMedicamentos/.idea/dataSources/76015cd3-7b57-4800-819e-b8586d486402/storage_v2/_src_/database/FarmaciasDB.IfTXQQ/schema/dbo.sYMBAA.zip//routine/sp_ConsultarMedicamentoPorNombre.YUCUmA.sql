CREATE PROCEDURE sp_ConsultarMedicamentoPorNombre @nombre VARCHAR(100)
AS
BEGIN
    SELECT *
    FROM Medicamentos
    WHERE CAST(id_medicamento AS varchar) = @nombre or nombre_comercial = @nombre
       OR nombre_generico = @nombre;
    UPDATE Medicamentos
    SET total_consultas = total_consultas + 1
    WHERE CAST(id_medicamento AS varchar) = @nombre or nombre_comercial = @nombre
       OR nombre_generico = @nombre;
END;
go

