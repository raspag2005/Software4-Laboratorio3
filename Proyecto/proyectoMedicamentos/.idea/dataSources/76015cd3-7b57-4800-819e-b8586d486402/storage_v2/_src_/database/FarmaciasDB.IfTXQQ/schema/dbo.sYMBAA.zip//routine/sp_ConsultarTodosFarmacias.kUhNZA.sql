CREATE PROCEDURE sp_ConsultarTodosFarmacias
AS
BEGIN
    SELECT * FROM farmacias
END;
go

